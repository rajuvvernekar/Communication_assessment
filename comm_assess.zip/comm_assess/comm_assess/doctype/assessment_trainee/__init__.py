# Assessment Trainee init
