# Assessment Record init
