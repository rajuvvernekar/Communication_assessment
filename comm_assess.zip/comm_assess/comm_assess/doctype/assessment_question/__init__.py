# Assessment Question init
